using namespace QPI;

struct CNAME2
{
};

struct CNAME : public ContractBase
{
	REGISTER_USER_FUNCTIONS_AND_PROCEDURES()
	{
	}

	INITIALIZE()
	{
	}

	BEGIN_EPOCH()
	{
	}

	END_EPOCH()
	{
	}

	BEGIN_TICK()
	{
	}

	END_TICK()
	{
	}

	PRE_ACQUIRE_SHARES()
	{
	}

	POST_ACQUIRE_SHARES()
	{
	}

	PRE_RELEASE_SHARES()
	{
	}

	POST_RELEASE_SHARES()
	{
	}

	POST_INCOMING_TRANSFER()
	{
	}

	EXPAND()
	{
	}
};
