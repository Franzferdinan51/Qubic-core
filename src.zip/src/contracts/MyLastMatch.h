using namespace QPI;

struct MLM2
{
};

struct MLM : public ContractBase
{
	REGISTER_USER_FUNCTIONS_AND_PROCEDURES()
	{
	}
};
