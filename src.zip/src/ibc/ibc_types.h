#pragma once

#include "../network_messages/common_def.h"
#include "../platform/m256.h"

// IBC protocol constants
#define IBC_CLIENT_TYPE_QUBIC "09-qubic"
#define IBC_CLIENT_TYPE_TENDERMINT "07-tendermint"
#define IBC_PORT_TRANSFER "transfer"
#define IBC_VERSION_TRANSFER "ics20-1"
#define MAX_IBC_CLIENTS 256
#define MAX_IBC_CONNECTIONS 512
#define MAX_IBC_CHANNELS 1024
#define MAX_PACKET_COMMITMENTS 4096
#define MAX_ACKNOWLEDGEMENTS 4096
#define QUORUM_THRESHOLD 451  // 2/3 + 1 of 676 computors

// IBC message types for Qubic transactions
#define IBC_CLIENT_CREATE 200
#define IBC_CLIENT_UPDATE 201
#define IBC_CONNECTION_OPEN_INIT 202
#define IBC_CONNECTION_OPEN_TRY 203
#define IBC_CONNECTION_OPEN_ACK 204
#define IBC_CONNECTION_OPEN_CONFIRM 205
#define IBC_CHANNEL_OPEN_INIT 206
#define IBC_CHANNEL_OPEN_TRY 207
#define IBC_CHANNEL_OPEN_ACK 208
#define IBC_CHANNEL_OPEN_CONFIRM 209
#define IBC_PACKET_SEND 210
#define IBC_PACKET_RECV 211
#define IBC_PACKET_ACK 212
#define IBC_PACKET_TIMEOUT 213

// IBC Client State
struct IBCClientState {
    char chainId[64];
    unsigned int latestEpoch;
    unsigned int latestTick;
    unsigned long long trustingPeriod;    // nanoseconds
    unsigned long long unbondingPeriod;   // nanoseconds
    unsigned long long maxClockDrift;     // nanoseconds
    m256i trustedComputors[NUMBER_OF_COMPUTORS];
    unsigned short numTrustedComputors;
    m256i merklePrefix;                   // Path prefix for state verification
    bool frozen;                          // Client frozen due to misbehavior
};

// IBC Consensus State  
struct IBCConsensusState {
    unsigned long long timestamp;         // Unix timestamp in nanoseconds
    unsigned int epoch;
    unsigned int tick;
    m256i spectrumDigest;                // Merkle root of account states
    m256i universeDigest;                // Merkle root of contract states
    m256i computorsDigest;               // Merkle root of computor set
    unsigned char signatures[NUMBER_OF_COMPUTORS][SIGNATURE_SIZE];
    unsigned short numSignatures;
    unsigned short signingComputorIndices[NUMBER_OF_COMPUTORS];
};

// IBC Connection states
enum IBCConnectionState {
    IBC_CONNECTION_UNINITIALIZED = 0,
    IBC_CONNECTION_INIT = 1,
    IBC_CONNECTION_TRYOPEN = 2,
    IBC_CONNECTION_OPEN = 3
};

// IBC Connection
struct IBCConnection {
    char connectionId[64];
    char clientId[64];
    char counterpartyConnectionId[64];
    char counterpartyClientId[64];
    char counterpartyPrefix[32];
    IBCConnectionState state;
    unsigned long long delayPeriod;       // Connection delay period
    m256i counterpartyCommitmentPrefix;   // For proof verification
};

// IBC Channel states
enum IBCChannelState {
    IBC_CHANNEL_UNINITIALIZED = 0,
    IBC_CHANNEL_INIT = 1,
    IBC_CHANNEL_TRYOPEN = 2,
    IBC_CHANNEL_OPEN = 3,
    IBC_CHANNEL_CLOSED = 4
};

// IBC Channel ordering
enum IBCChannelOrdering {
    IBC_CHANNEL_UNORDERED = 0,
    IBC_CHANNEL_ORDERED = 1
};

// IBC Channel
struct IBCChannel {
    char portId[64];
    char channelId[64];
    char counterpartyPortId[64]; 
    char counterpartyChannelId[64];
    char connectionId[64];
    IBCChannelState state;
    IBCChannelOrdering ordering;
    char version[32];
    unsigned long long nextSequenceSend;
    unsigned long long nextSequenceRecv;
    unsigned long long nextSequenceAck;
};

// IBC Packet
struct IBCPacket {
    unsigned long long sequence;
    char sourcePort[64];
    char sourceChannel[64];
    char destinationPort[64];
    char destinationChannel[64];
    unsigned char data[MAX_INPUT_SIZE];
    unsigned short dataSize;
    unsigned int timeoutTick;             // Qubic tick timeout
    unsigned long long timeoutTimestamp;  // Unix timestamp timeout
};

// IBC Header for light client updates
struct IBCQubicHeader {
    unsigned int epoch;
    unsigned int tick;
    unsigned long long timestamp;
    m256i spectrumDigest;
    m256i universeDigest;
    m256i computorsDigest;
    m256i transactionDigest;
    unsigned char signatures[NUMBER_OF_COMPUTORS][SIGNATURE_SIZE];
    unsigned short numSignatures;
    unsigned short signingComputorIndices[NUMBER_OF_COMPUTORS];
    m256i prevSpectrumDigest;             // Previous state for validation
    m256i prevUniverseDigest;
    m256i prevComputersDigest;
};

// IBC Misbehavior evidence
struct IBCMisbehavior {
    char clientId[64];
    IBCQubicHeader header1;
    IBCQubicHeader header2;
    unsigned long long timestamp;
};

// IBC Transaction types
struct IBCCreateClientTransaction {
    char clientType[32];                  // "09-qubic", "07-tendermint", etc.
    unsigned char clientState[1024];
    unsigned short clientStateSize;
    unsigned char consensusState[512];
    unsigned short consensusStateSize;
};

struct IBCUpdateClientTransaction {
    char clientId[64];
    unsigned char header[2048];
    unsigned short headerSize;
};

struct IBCConnectionOpenInitTransaction {
    char connectionId[64];
    char clientId[64];
    char counterpartyClientId[64];
    char counterpartyConnectionId[64];
    unsigned long long delayPeriod;
};

struct IBCConnectionOpenTryTransaction {
    char connectionId[64];
    char clientId[64];
    char counterpartyConnectionId[64];
    char counterpartyClientId[64];
    unsigned long long delayPeriod;
    unsigned char proofInit[1024];
    unsigned short proofInitSize;
    unsigned char proofClient[1024];
    unsigned short proofClientSize;
    unsigned char proofConsensus[1024];
    unsigned short proofConsensusSize;
    unsigned int proofHeight;
    unsigned int consensusHeight;
};

struct IBCChannelOpenInitTransaction {
    char portId[64];
    char channelId[64];
    char connectionId[64];
    char counterpartyPortId[64];
    IBCChannelOrdering ordering;
    char version[32];
};

struct IBCSendPacketTransaction {
    IBCPacket packet;
    unsigned char acknowledgement[256];   // Expected acknowledgement
    unsigned short acknowledgementSize;
};

struct IBCRecvPacketTransaction {
    IBCPacket packet;
    unsigned char proof[1024];            // Proof of packet commitment
    unsigned short proofSize;
    unsigned int proofHeight;
};

struct IBCAcknowledgePacketTransaction {
    IBCPacket packet;
    unsigned char acknowledgement[256];
    unsigned short acknowledgementSize;
    unsigned char proof[1024];            // Proof of acknowledgement
    unsigned short proofSize;
    unsigned int proofHeight;
};

// IBC Transfer application data
struct IBCTransferData {
    char denom[64];                       // Token denomination (e.g., "qubic", "atom")
    unsigned long long amount;            // Transfer amount
    char sender[64];                      // Sender address
    char receiver[64];                    // Receiver address
    unsigned char memo[256];              // Optional memo
    unsigned short memoSize;
};

// IBC packet commitment (hash of packet data)
struct IBCPacketCommitment {
    char portId[64];
    char channelId[64];
    unsigned long long sequence;
    m256i commitment;                     // Hash of packet data
};

// IBC acknowledgement
struct IBCAcknowledgement {
    char portId[64];
    char channelId[64];
    unsigned long long sequence;
    unsigned char data[256];              // Acknowledgement data
    unsigned short dataSize;
    m256i hash;                          // Hash of acknowledgement
};

// Merkle proof structure for IBC verification
struct IBCMerkleProof {
    unsigned char proof[2048];            // Serialized merkle proof
    unsigned short proofSize;
    char path[128];                       // Key path (e.g., "spectrum/address", "universe/contract")
    unsigned char value[512];             // Value being proved
    unsigned short valueSize;
    m256i root;                          // Merkle root to verify against
};

// IBC State - main container for all IBC data
struct IBCState {
    // Client management
    IBCClientState clients[MAX_IBC_CLIENTS];
    char clientIds[MAX_IBC_CLIENTS][64];
    unsigned short numClients;
    
    // Consensus states (indexed by client + height)
    IBCConsensusState consensusStates[MAX_IBC_CLIENTS * 100];  // 100 states per client max
    unsigned int numConsensusStates;
    
    // Connection management
    IBCConnection connections[MAX_IBC_CONNECTIONS];
    char connectionIds[MAX_IBC_CONNECTIONS][64];
    unsigned short numConnections;
    
    // Channel management
    IBCChannel channels[MAX_IBC_CHANNELS];
    char channelIds[MAX_IBC_CHANNELS][64];
    unsigned short numChannels;
    
    // Packet commitments
    IBCPacketCommitment packetCommitments[MAX_PACKET_COMMITMENTS];
    unsigned int numPacketCommitments;
    
    // Acknowledgements
    IBCAcknowledgement acknowledgements[MAX_ACKNOWLEDGEMENTS];
    unsigned int numAcknowledgements;
    
    // Next available identifiers
    unsigned int nextClientSequence;
    unsigned int nextConnectionSequence;
    unsigned int nextChannelSequence;
};

// Function declarations
bool initializeIBCState();
bool processIBCTransaction(const Transaction* transaction);
bool verifyClientState(const IBCClientState* clientState);
bool verifyConsensusState(const IBCConsensusState* consensusState);
bool updateClientState(const char* clientId, const IBCQubicHeader* header);
bool createMerkleProof(const char* path, const unsigned char* value, unsigned short valueSize, IBCMerkleProof* proof);
bool verifyMerkleProof(const IBCMerkleProof* proof);
bool verifyQuorumSignatures(const IBCQubicHeader* header, const IBCClientState* clientState);
IBCClientState* findClient(const char* clientId);
IBCConnection* findConnection(const char* connectionId);
IBCChannel* findChannel(const char* portId, const char* channelId);
bool storePacketCommitment(const IBCPacket* packet);
bool verifyPacketCommitment(const IBCPacket* packet, const unsigned char* proof, unsigned short proofSize);
m256i hashPacket(const IBCPacket* packet);
m256i hashAcknowledgement(const unsigned char* ack, unsigned short ackSize);

// Global IBC state
extern IBCState ibcState;