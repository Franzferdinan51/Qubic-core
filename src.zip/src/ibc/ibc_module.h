#pragma once

#include "ibc_types.h"
#include "../platform/m256.h"
#include "../kangaroo_twelve.h"

// IBC Module - Core implementation for Inter-Blockchain Communication
class IBCModule {
private:
    static bool initialized;
    
    // Client management
    static bool validateClientIdentifier(const char* clientId);
    static bool validateConnectionIdentifier(const char* connectionId);
    static bool validateChannelIdentifier(const char* channelId);
    static bool validatePortIdentifier(const char* portId);
    
    // State validation
    static bool validateQubicHeader(const IBCQubicHeader* header);
    static bool validateClientState(const IBCClientState* clientState);
    static bool validateConsensusState(const IBCConsensusState* consensusState);
    
    // Cryptographic verification
    static bool verifySignature(const m256i* publicKey, const unsigned char* message, 
                               unsigned int messageSize, const unsigned char* signature);
    static bool verifyFourQSignature(const m256i* publicKey, const unsigned char* message, 
                                    unsigned int messageSize, const unsigned char* signature);
    
    // Merkle proof utilities
    static bool generateSpectrumProof(const m256i* publicKey, IBCMerkleProof* proof);
    static bool generateUniverseProof(unsigned int contractIndex, const unsigned char* contractState, 
                                     unsigned short stateSize, IBCMerkleProof* proof);
    static bool verifySpectrumProof(const IBCMerkleProof* proof);
    static bool verifyUniverseProof(const IBCMerkleProof* proof);
    
    // Connection handshake helpers
    static bool processConnectionOpenInit(const IBCConnectionOpenInitTransaction* tx);
    static bool processConnectionOpenTry(const IBCConnectionOpenTryTransaction* tx);
    static bool processConnectionOpenAck(const Transaction* tx);
    static bool processConnectionOpenConfirm(const Transaction* tx);
    
    // Channel handshake helpers
    static bool processChannelOpenInit(const IBCChannelOpenInitTransaction* tx);
    static bool processChannelOpenTry(const Transaction* tx);
    static bool processChannelOpenAck(const Transaction* tx);
    static bool processChannelOpenConfirm(const Transaction* tx);
    
    // Packet lifecycle
    static bool processSendPacket(const IBCSendPacketTransaction* tx);
    static bool processRecvPacket(const IBCRecvPacketTransaction* tx);
    static bool processAcknowledgePacket(const IBCAcknowledgePacketTransaction* tx);
    static bool processTimeoutPacket(const Transaction* tx);
    
    // Transfer application
    static bool processTransferPacket(const IBCPacket* packet);
    static bool validateTransferData(const IBCTransferData* transferData);
    static bool executeTransfer(const IBCTransferData* transferData, const char* sourceChannel);
    
public:
    // Initialization
    static bool initialize();
    static bool isInitialized() { return initialized; }
    
    // Main transaction processor
    static bool processTransaction(const Transaction* transaction);
    
    // Client lifecycle management
    static bool createClient(const IBCCreateClientTransaction* tx);
    static bool updateClient(const IBCUpdateClientTransaction* tx);
    static bool submitMisbehaviour(const IBCMisbehavior* misbehaviour);
    
    // State queries
    static IBCClientState* getClientState(const char* clientId);
    static IBCConsensusState* getConsensusState(const char* clientId, unsigned int epoch, unsigned int tick);
    static IBCConnection* getConnection(const char* connectionId);
    static IBCChannel* getChannel(const char* portId, const char* channelId);
    
    // Packet management
    static bool hasPacketCommitment(const char* portId, const char* channelId, unsigned long long sequence);
    static bool hasPacketAcknowledgement(const char* portId, const char* channelId, unsigned long long sequence);
    static m256i getPacketCommitment(const char* portId, const char* channelId, unsigned long long sequence);
    static bool getPacketAcknowledgement(const char* portId, const char* channelId, 
                                        unsigned long long sequence, unsigned char* ack, unsigned short* ackSize);
    
    // Proof generation for relayers
    static bool generateClientStateProof(const char* clientId, IBCMerkleProof* proof);
    static bool generateConsensusStateProof(const char* clientId, unsigned int epoch, 
                                           unsigned int tick, IBCMerkleProof* proof);
    static bool generateConnectionProof(const char* connectionId, IBCMerkleProof* proof);
    static bool generateChannelProof(const char* portId, const char* channelId, IBCMerkleProof* proof);
    static bool generatePacketCommitmentProof(const char* portId, const char* channelId, 
                                             unsigned long long sequence, IBCMerkleProof* proof);
    static bool generatePacketAcknowledgementProof(const char* portId, const char* channelId, 
                                                   unsigned long long sequence, IBCMerkleProof* proof);
    
    // Timeout handling
    static bool isPacketTimedOut(const IBCPacket* packet, unsigned int currentTick, 
                                unsigned long long currentTimestamp);
    static bool cleanupTimedOutPackets(unsigned int currentTick, unsigned long long currentTimestamp);
    
    // State management
    static bool saveIBCState();
    static bool loadIBCState();
    static void resetIBCState();
    
    // Utility functions
    static void generateClientId(char* clientId, const char* clientType);
    static void generateConnectionId(char* connectionId);
    static void generateChannelId(char* channelId);
    static bool parseTransferData(const unsigned char* data, unsigned short dataSize, 
                                 IBCTransferData* transferData);
    static bool serializeTransferData(const IBCTransferData* transferData, 
                                     unsigned char* data, unsigned short* dataSize);
    
    // Validation helpers
    static bool isValidAddress(const char* address);
    static bool isValidDenom(const char* denom);
    static bool isValidAmount(unsigned long long amount);
    
    // Cross-chain verification
    static bool verifyClientMessage(const char* clientId, const IBCQubicHeader* header);
    static bool verifyMembership(const char* clientId, unsigned int epoch, unsigned int tick,
                                const IBCMerkleProof* proof);
    static bool verifyNonMembership(const char* clientId, unsigned int epoch, unsigned int tick,
                                   const IBCMerkleProof* proof);
    
    // Event emission (for relayers)
    static void emitClientCreated(const char* clientId, const char* clientType);
    static void emitClientUpdated(const char* clientId, unsigned int epoch, unsigned int tick);
    static void emitConnectionOpened(const char* connectionId, const char* clientId, 
                                    const char* counterpartyConnectionId);
    static void emitChannelOpened(const char* portId, const char* channelId, 
                                 const char* connectionId, const char* counterpartyPortId, 
                                 const char* counterpartyChannelId);
    static void emitPacketSent(const IBCPacket* packet);
    static void emitPacketReceived(const IBCPacket* packet);
    static void emitPacketAcknowledged(const IBCPacket* packet, const unsigned char* ack, 
                                      unsigned short ackSize);
    static void emitPacketTimeout(const IBCPacket* packet);
    
    // Debug and testing utilities
    static void printIBCState();
    static bool validateIBCState();
    static unsigned int getClientCount() { return ibcState.numClients; }
    static unsigned int getConnectionCount() { return ibcState.numConnections; }
    static unsigned int getChannelCount() { return ibcState.numChannels; }
    static unsigned int getPacketCommitmentCount() { return ibcState.numPacketCommitments; }
    static unsigned int getAcknowledgementCount() { return ibcState.numAcknowledgements; }
};

// IBC Height structure for compatibility with Cosmos SDK
struct IBCHeight {
    unsigned int revisionNumber;  // Epoch in Qubic
    unsigned int revisionHeight;  // Tick in Qubic
    
    IBCHeight(unsigned int epoch = 0, unsigned int tick = 0) 
        : revisionNumber(epoch), revisionHeight(tick) {}
    
    bool isZero() const { return revisionNumber == 0 && revisionHeight == 0; }
    
    bool operator<(const IBCHeight& other) const {
        if (revisionNumber != other.revisionNumber) {
            return revisionNumber < other.revisionNumber;
        }
        return revisionHeight < other.revisionHeight;
    }
    
    bool operator==(const IBCHeight& other) const {
        return revisionNumber == other.revisionNumber && revisionHeight == other.revisionHeight;
    }
    
    bool operator>(const IBCHeight& other) const {
        return !(*this < other) && !(*this == other);
    }
};

// IBC Path structure for state commitment paths
struct IBCPath {
    char path[256];
    
    IBCPath(const char* p) {
        strncpy(path, p, sizeof(path) - 1);
        path[sizeof(path) - 1] = '\0';
    }
    
    // Standard IBC paths
    static IBCPath clientStatePath(const char* clientId) {
        char p[256];
        snprintf(p, sizeof(p), "clients/%s/clientState", clientId);
        return IBCPath(p);
    }
    
    static IBCPath consensusStatePath(const char* clientId, const IBCHeight& height) {
        char p[256];
        snprintf(p, sizeof(p), "clients/%s/consensusStates/%u-%u", 
                clientId, height.revisionNumber, height.revisionHeight);
        return IBCPath(p);
    }
    
    static IBCPath connectionPath(const char* connectionId) {
        char p[256];
        snprintf(p, sizeof(p), "connections/%s", connectionId);
        return IBCPath(p);
    }
    
    static IBCPath channelPath(const char* portId, const char* channelId) {
        char p[256];
        snprintf(p, sizeof(p), "channelEnds/ports/%s/channels/%s", portId, channelId);
        return IBCPath(p);
    }
    
    static IBCPath packetCommitmentPath(const char* portId, const char* channelId, 
                                       unsigned long long sequence) {
        char p[256];
        snprintf(p, sizeof(p), "commitments/ports/%s/channels/%s/sequences/%llu", 
                portId, channelId, sequence);
        return IBCPath(p);
    }
    
    static IBCPath packetAcknowledgementPath(const char* portId, const char* channelId, 
                                            unsigned long long sequence) {
        char p[256];
        snprintf(p, sizeof(p), "acks/ports/%s/channels/%s/sequences/%llu", 
                portId, channelId, sequence);
        return IBCPath(p);
    }
    
    static IBCPath nextSequenceSendPath(const char* portId, const char* channelId) {
        char p[256];
        snprintf(p, sizeof(p), "nextSequenceSend/ports/%s/channels/%s", portId, channelId);
        return IBCPath(p);
    }
    
    static IBCPath nextSequenceRecvPath(const char* portId, const char* channelId) {
        char p[256];
        snprintf(p, sizeof(p), "nextSequenceRecv/ports/%s/channels/%s", portId, channelId);
        return IBCPath(p);
    }
};

// Error codes for IBC operations
enum IBCError {
    IBC_SUCCESS = 0,
    IBC_ERROR_INVALID_CLIENT = 1,
    IBC_ERROR_CLIENT_NOT_FOUND = 2,
    IBC_ERROR_CLIENT_FROZEN = 3,
    IBC_ERROR_INVALID_CONSENSUS_STATE = 4,
    IBC_ERROR_CONSENSUS_STATE_NOT_FOUND = 5,
    IBC_ERROR_INVALID_CONNECTION = 6,
    IBC_ERROR_CONNECTION_NOT_FOUND = 7,
    IBC_ERROR_INVALID_CHANNEL = 8,
    IBC_ERROR_CHANNEL_NOT_FOUND = 9,
    IBC_ERROR_INVALID_PACKET = 10,
    IBC_ERROR_PACKET_TIMEOUT = 11,
    IBC_ERROR_INVALID_PROOF = 12,
    IBC_ERROR_INSUFFICIENT_SIGNATURES = 13,
    IBC_ERROR_INVALID_SIGNATURE = 14,
    IBC_ERROR_HEADER_VERIFICATION_FAILED = 15,
    IBC_ERROR_MISBEHAVIOUR_DETECTED = 16,
    IBC_ERROR_INVALID_IDENTIFIER = 17,
    IBC_ERROR_SEQUENCE_MISMATCH = 18,
    IBC_ERROR_ACKNOWLEDGEMENT_ALREADY_EXISTS = 19,
    IBC_ERROR_COMMITMENT_NOT_FOUND = 20,
    IBC_ERROR_INVALID_HEIGHT = 21,
    IBC_ERROR_EXPIRED_CLIENT = 22,
    IBC_ERROR_INVALID_TRANSFER_DATA = 23,
    IBC_ERROR_INSUFFICIENT_FUNDS = 24,
    IBC_ERROR_INVALID_ADDRESS = 25,
    IBC_ERROR_STATE_SERIALIZATION_FAILED = 26,
    IBC_ERROR_UNKNOWN = 999
};

// Constants for IBC implementation
#define IBC_IDENTIFIER_PREFIX_CLIENT "07-qubic-"
#define IBC_IDENTIFIER_PREFIX_CONNECTION "connection-"
#define IBC_IDENTIFIER_PREFIX_CHANNEL "channel-"
#define IBC_COMMITMENT_PREFIX "ibc"
#define IBC_DEFAULT_DELAY_PERIOD 0
#define IBC_TRANSFER_PORT "transfer"
#define IBC_TRANSFER_VERSION "ics20-1"

// IBC commitment root for Qubic
#define IBC_QUBIC_COMMITMENT_ROOT_SPECTRUM 0
#define IBC_QUBIC_COMMITMENT_ROOT_UNIVERSE 1
#define IBC_QUBIC_COMMITMENT_ROOT_COMPUTORS 2