struct Price : public OracleBase
{
	// TODO
};